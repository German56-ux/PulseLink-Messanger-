
-- ROLES
create type public.app_role as enum ('admin','moderator','user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "read own roles" on public.user_roles for select to authenticated
using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "admins manage roles" on public.user_roles for all to authenticated
using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- PROFILES
create table public.profiles (
  id uuid primary key,
  username text not null unique,
  display_name text not null default '',
  bio text not null default '',
  avatar_url text,
  last_seen timestamptz not null default now(),
  is_banned boolean not null default false,
  ban_reason text,
  privacy_last_seen text not null default 'everybody',
  privacy_avatar text not null default 'everybody',
  privacy_messages text not null default 'everybody',
  read_receipts boolean not null default true,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create policy "profiles readable by authenticated" on public.profiles for select to authenticated using (true);
create policy "insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "update own profile" on public.profiles for update to authenticated
using (id = auth.uid() or public.has_role(auth.uid(),'admin'))
with check (id = auth.uid() or public.has_role(auth.uid(),'admin'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', 'user_' || substr(replace(new.id::text,'-',''),1,8)),
    coalesce(new.raw_user_meta_data->>'display_name', split_part(coalesce(new.email,'user'),'@',1))
  )
  on conflict (id) do nothing;
  insert into public.user_roles (user_id, role) values (new.id, 'user') on conflict do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- CHATS
create table public.chats (
  id uuid primary key default gen_random_uuid(),
  type text not null default 'direct',
  title text,
  avatar_url text,
  created_by uuid not null,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);
grant select, insert, update, delete on public.chats to authenticated;
grant all on public.chats to service_role;
alter table public.chats enable row level security;

create table public.chat_members (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  user_id uuid not null,
  role text not null default 'member',
  last_read_at timestamptz not null default now(),
  joined_at timestamptz not null default now(),
  unique (chat_id, user_id)
);
grant select, insert, update, delete on public.chat_members to authenticated;
grant all on public.chat_members to service_role;
alter table public.chat_members enable row level security;

create or replace function public.is_chat_member(_chat_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = _user_id)
$$;

create or replace function public.is_chat_admin(_chat_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.chat_members where chat_id = _chat_id and user_id = _user_id and role = 'owner')
$$;

create policy "members read chats" on public.chats for select to authenticated
using (public.is_chat_member(id, auth.uid()) or public.has_role(auth.uid(),'admin'));
create policy "create chats" on public.chats for insert to authenticated with check (created_by = auth.uid());
create policy "owners update chats" on public.chats for update to authenticated
using (public.is_chat_admin(id, auth.uid()) or public.has_role(auth.uid(),'admin'))
with check (true);
create policy "owners delete chats" on public.chats for delete to authenticated
using (public.is_chat_admin(id, auth.uid()) or public.has_role(auth.uid(),'admin'));

create policy "read chat members" on public.chat_members for select to authenticated
using (public.is_chat_member(chat_id, auth.uid()) or user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "add chat members" on public.chat_members for insert to authenticated
with check (user_id = auth.uid() or public.is_chat_admin(chat_id, auth.uid()) or exists (select 1 from public.chats c where c.id = chat_id and c.created_by = auth.uid()));
create policy "update own membership" on public.chat_members for update to authenticated
using (user_id = auth.uid() or public.is_chat_admin(chat_id, auth.uid())) with check (true);
create policy "leave or remove members" on public.chat_members for delete to authenticated
using (user_id = auth.uid() or public.is_chat_admin(chat_id, auth.uid()) or public.has_role(auth.uid(),'admin'));

-- MESSAGES
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  sender_id uuid not null,
  content text not null default '',
  attachment_url text,
  attachment_type text,
  reply_to uuid,
  is_deleted boolean not null default false,
  edited_at timestamptz,
  created_at timestamptz not null default now()
);
create index messages_chat_created_idx on public.messages (chat_id, created_at);
grant select, insert, update, delete on public.messages to authenticated;
grant all on public.messages to service_role;
alter table public.messages enable row level security;

create policy "members read messages" on public.messages for select to authenticated
using (public.is_chat_member(chat_id, auth.uid()) or public.has_role(auth.uid(),'admin'));
create policy "members send messages" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and public.is_chat_member(chat_id, auth.uid()));
create policy "edit own messages" on public.messages for update to authenticated
using (sender_id = auth.uid()) with check (sender_id = auth.uid());
create policy "delete own messages" on public.messages for delete to authenticated
using (sender_id = auth.uid() or public.has_role(auth.uid(),'admin') or public.is_chat_admin(chat_id, auth.uid()));

create or replace function public.bump_chat_activity()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  update public.chats set last_message_at = now() where id = new.chat_id;
  return new;
end;
$$;
create trigger messages_bump_chat after insert on public.messages
for each row execute function public.bump_chat_activity();

-- BLOCKS
create table public.blocked_users (
  id uuid primary key default gen_random_uuid(),
  blocker_id uuid not null,
  blocked_id uuid not null,
  created_at timestamptz not null default now(),
  unique (blocker_id, blocked_id)
);
grant select, insert, delete on public.blocked_users to authenticated;
grant all on public.blocked_users to service_role;
alter table public.blocked_users enable row level security;
create policy "manage own blocks" on public.blocked_users for all to authenticated
using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

-- REALTIME
alter table public.messages replica identity full;
alter table public.chats replica identity full;
alter table public.chat_members replica identity full;
alter table public.profiles replica identity full;
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.chats;
alter publication supabase_realtime add table public.chat_members;
alter publication supabase_realtime add table public.profiles;
