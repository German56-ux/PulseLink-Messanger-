-- profiles flags
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_business boolean NOT NULL DEFAULT false;

-- chats: channel support
ALTER TABLE public.chats
  ADD COLUMN IF NOT EXISTS username text,
  ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS is_verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_business boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_public boolean NOT NULL DEFAULT false;

CREATE UNIQUE INDEX IF NOT EXISTS chats_username_lower_idx ON public.chats (lower(username)) WHERE username IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_idx ON public.profiles (lower(username));

-- username availability across profiles and channels
CREATE OR REPLACE FUNCTION public.is_username_available(_username text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  select not exists (select 1 from public.profiles where lower(username) = lower(trim(_username)))
     and not exists (select 1 from public.chats where lower(username) = lower(trim(_username)))
$$;

-- public channels are visible to all authenticated users
DROP POLICY IF EXISTS "public channels readable" ON public.chats;
CREATE POLICY "public channels readable" ON public.chats
  FOR SELECT TO authenticated
  USING (is_public = true);

-- anyone can join a public channel as member (only for themselves)
DROP POLICY IF EXISTS "join public channels" ON public.chat_members;
CREATE POLICY "join public channels" ON public.chat_members
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND role = 'member'
    AND EXISTS (SELECT 1 FROM public.chats c WHERE c.id = chat_id AND c.is_public = true)
  );

-- only channel owners/admins may post in channels
DROP POLICY IF EXISTS "members send messages" ON public.messages;
CREATE POLICY "members send messages" ON public.messages
  FOR INSERT TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND public.is_chat_member(chat_id, auth.uid())
    AND (
      NOT EXISTS (SELECT 1 FROM public.chats c WHERE c.id = chat_id AND c.type = 'channel')
      OR public.is_chat_admin(chat_id, auth.uid())
      OR public.has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- reports
CREATE TABLE IF NOT EXISTS public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  target_label text NOT NULL DEFAULT '',
  reason text NOT NULL,
  details text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "create own reports" ON public.reports;
CREATE POLICY "create own reports" ON public.reports
  FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid());

DROP POLICY IF EXISTS "read own or staff reports" ON public.reports;
CREATE POLICY "read own or staff reports" ON public.reports
  FOR SELECT TO authenticated
  USING (reporter_id = auth.uid() OR public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'moderator'::app_role));

DROP POLICY IF EXISTS "staff update reports" ON public.reports;
CREATE POLICY "staff update reports" ON public.reports
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'moderator'::app_role))
  WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

DROP TRIGGER IF EXISTS update_reports_updated_at ON public.reports;
CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON public.reports
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- restore chat activity trigger for messages
DROP TRIGGER IF EXISTS bump_chat_activity_trg ON public.messages;
CREATE TRIGGER bump_chat_activity_trg AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.bump_chat_activity();

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- official PulsLink channel
DO $$
DECLARE owner_id uuid; ch_id uuid; u record;
BEGIN
  SELECT id INTO owner_id FROM public.profiles ORDER BY created_at LIMIT 1;
  IF owner_id IS NULL THEN RETURN; END IF;

  SELECT id INTO ch_id FROM public.chats WHERE lower(username) = 'pulslink';
  IF ch_id IS NULL THEN
    INSERT INTO public.chats (type, title, username, description, created_by, is_public, is_verified, is_business)
    VALUES ('channel', 'PulsLink', 'pulslink', 'Официальный канал мессенджера PulsLink. Новости, обновления и анонсы.', owner_id, true, true, true)
    RETURNING id INTO ch_id;

    INSERT INTO public.messages (chat_id, sender_id, content)
    VALUES (ch_id, owner_id, 'Добро пожаловать в официальный канал PulsLink! Здесь мы публикуем новости и обновления.');
  END IF;

  FOR u IN SELECT id FROM public.profiles LOOP
    INSERT INTO public.chat_members (chat_id, user_id, role) VALUES (ch_id, u.id, 'owner')
    ON CONFLICT DO NOTHING;
    INSERT INTO public.user_roles (user_id, role) VALUES (u.id, 'admin') ON CONFLICT DO NOTHING;
    UPDATE public.profiles SET is_verified = true, is_business = true WHERE id = u.id;
  END LOOP;
END $$;

-- recreate profile trigger
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();