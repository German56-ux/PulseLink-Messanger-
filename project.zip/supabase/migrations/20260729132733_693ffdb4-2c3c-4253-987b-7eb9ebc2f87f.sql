
create policy "pulslink read" on storage.objects for select to authenticated using (bucket_id = 'pulslink');
create policy "pulslink upload own" on storage.objects for insert to authenticated
with check (bucket_id = 'pulslink' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "pulslink update own" on storage.objects for update to authenticated
using (bucket_id = 'pulslink' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "pulslink delete own" on storage.objects for delete to authenticated
using (bucket_id = 'pulslink' and (storage.foldername(name))[1] = auth.uid()::text);
