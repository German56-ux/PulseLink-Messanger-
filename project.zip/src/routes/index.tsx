import { createFileRoute, Link } from "@tanstack/react-router";
import { MessageCircle, ShieldCheck, Lock, Users, Zap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "PulsLink — мессенджер с 2FA и приватностью" },
      {
        name: "description",
        content:
          "PulsLink: личные и групповые чаты в реальном времени, файлы, двухфакторная защита, тонкие настройки приватности и админ-панель.",
      },
      { property: "og:title", content: "PulsLink — мессенджер с 2FA и приватностью" },
      {
        property: "og:description",
        content: "Чаты в реальном времени, вложения, 2FA и приватность под вашим контролем.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: Zap, title: "Мгновенные чаты", text: "Сообщения доставляются в реальном времени, без перезагрузок." },
  { icon: Users, title: "Группы", text: "Групповые чаты с участниками, ролями и общим доступом к файлам." },
  { icon: ShieldCheck, title: "2FA", text: "Двухфакторное подтверждение входа через приложение-аутентификатор." },
  { icon: Lock, title: "Приватность", text: "Кто видит время визита, аватар и кто может писать — решаете вы." },
];

function Landing() {
  const { session, loading } = useSession();

  return (
    <main className="chat-canvas min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
        <div className="flex items-center gap-2">
          <span className="gradient-pulse flex size-9 items-center justify-center rounded-2xl text-primary-foreground">
            <MessageCircle className="size-5" />
          </span>
          <span className="font-display text-xl">PulsLink</span>
        </div>
        <Button asChild variant="secondary">
          <Link to={session ? "/chats" : "/auth"}>{loading ? "…" : session ? "Открыть чаты" : "Войти"}</Link>
        </Button>
      </header>

      <section className="mx-auto max-w-6xl px-5 pt-10 pb-16 md:pt-20">
        <p className="text-sm uppercase tracking-[0.3em] text-primary">мессенджер</p>
        <h1 className="mt-4 max-w-3xl text-4xl leading-tight md:text-6xl">
          Общайтесь на скорости пульса
        </h1>
        <p className="mt-5 max-w-xl text-base text-muted-foreground md:text-lg">
          Личные и групповые чаты, вложения, двухфакторная защита и полный контроль приватности —
          всё в одном приложении.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button asChild size="lg" className="gradient-pulse text-primary-foreground shadow-[var(--shadow-pulse)]">
            <Link to={session ? "/chats" : "/auth"}>
              Начать общение <ArrowRight className="ml-1 size-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/auth">Создать аккаунт</Link>
          </Button>
        </div>

        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="surface-panel rounded-3xl border border-border p-5">
              <span className="flex size-10 items-center justify-center rounded-2xl bg-secondary text-primary">
                <f.icon className="size-5" />
              </span>
              <h2 className="mt-4 font-display text-lg">{f.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        PulsLink · {new Date().getFullYear()}
      </footer>
    </main>
  );
}
