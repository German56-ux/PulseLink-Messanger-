import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { MessageCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Вход в PulsLink" },
      { name: "description", content: "Войдите или создайте аккаунт PulsLink: почта, пароль, Google и 2FA." },
      { property: "og:title", content: "Вход в PulsLink" },
      { property: "og:description", content: "Войдите в PulsLink — мессенджер с 2FA и приватностью." },
    ],
  }),
  component: AuthPage,
});

const signUpSchema = z.object({
  email: z.string().trim().email("Некорректная почта").max(255),
  password: z.string().min(8, "Минимум 8 символов").max(72),
  username: z
    .string()
    .trim()
    .min(3, "Минимум 3 символа")
    .max(24)
    .regex(/^[a-zA-Z0-9_]+$/, "Только латиница, цифры и _"),
  displayName: z.string().trim().min(1, "Укажите имя").max(48),
});

function AuthPage() {
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const [mfaFactorId, setMfaFactorId] = useState<string | null>(null);
  const [otp, setOtp] = useState("");

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");

  async function afterAuth() {
    const { data } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
    if (data?.nextLevel === "aal2" && data.nextLevel !== data.currentLevel) {
      const { data: factors } = await supabase.auth.mfa.listFactors();
      const factor = factors?.totp?.[0];
      if (factor) {
        setMfaFactorId(factor.id);
        return;
      }
    }
    navigate({ to: "/chats" });
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({
      email: loginEmail.trim(),
      password: loginPassword,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    await afterAuth();
  }

  async function handleSignUp(e: React.FormEvent) {
    e.preventDefault();
    const parsed = signUpSchema.safeParse({ email, password, username, displayName });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { username: parsed.data.username, display_name: parsed.data.displayName },
      },
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Аккаунт создан");
    await afterAuth();
  }

  async function handleGoogle() {
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      toast.error("Не удалось войти через Google");
      return;
    }
    if (result.redirected) return;
    await afterAuth();
  }

  async function handleVerifyOtp() {
    if (!mfaFactorId || otp.length !== 6) return;
    setBusy(true);
    const { data: challenge, error: challengeError } = await supabase.auth.mfa.challenge({
      factorId: mfaFactorId,
    });
    if (challengeError || !challenge) {
      setBusy(false);
      toast.error(challengeError?.message ?? "Ошибка проверки");
      return;
    }
    const { error } = await supabase.auth.mfa.verify({
      factorId: mfaFactorId,
      challengeId: challenge.id,
      code: otp,
    });
    setBusy(false);
    if (error) {
      toast.error("Неверный код");
      return;
    }
    navigate({ to: "/chats" });
  }

  if (mfaFactorId) {
    return (
      <main className="chat-canvas flex min-h-screen items-center justify-center px-5">
        <div className="surface-panel w-full max-w-sm rounded-3xl border border-border p-7 text-center">
          <h1 className="font-display text-2xl">Подтверждение входа</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Введите 6-значный код из приложения-аутентификатора.
          </p>
          <div className="mt-6 flex justify-center">
            <InputOTP maxLength={6} value={otp} onChange={setOtp}>
              <InputOTPGroup>
                {[0, 1, 2, 3, 4, 5].map((i) => (
                  <InputOTPSlot key={i} index={i} />
                ))}
              </InputOTPGroup>
            </InputOTP>
          </div>
          <Button className="mt-6 w-full" disabled={busy || otp.length !== 6} onClick={handleVerifyOtp}>
            {busy ? <Loader2 className="size-4 animate-spin" /> : "Подтвердить"}
          </Button>
        </div>
      </main>
    );
  }

  return (
    <main className="chat-canvas flex min-h-screen items-center justify-center px-5 py-10">
      <div className="surface-panel w-full max-w-md rounded-3xl border border-border p-7">
        <div className="mb-6 flex items-center gap-2">
          <span className="gradient-pulse flex size-9 items-center justify-center rounded-2xl text-primary-foreground">
            <MessageCircle className="size-5" />
          </span>
          <span className="font-display text-xl">PulsLink</span>
        </div>

        <Tabs defaultValue="login">
          <TabsList className="w-full">
            <TabsTrigger value="login" className="flex-1">
              Вход
            </TabsTrigger>
            <TabsTrigger value="signup" className="flex-1">
              Регистрация
            </TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <form className="mt-5 space-y-4" onSubmit={handleLogin}>
              <div className="space-y-2">
                <Label htmlFor="login-email">Почта</Label>
                <Input
                  id="login-email"
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                  maxLength={255}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password">Пароль</Label>
                <Input
                  id="login-password"
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  required
                  maxLength={72}
                />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : "Войти"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="signup">
            <form className="mt-5 space-y-4" onSubmit={handleSignUp}>
              <div className="space-y-2">
                <Label htmlFor="name">Имя</Label>
                <Input
                  id="name"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={48}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Никнейм</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="pulse_user"
                  maxLength={24}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Почта</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  maxLength={255}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Пароль</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  maxLength={72}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={busy}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : "Создать аккаунт"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="h-px flex-1 bg-border" />
          или
          <span className="h-px flex-1 bg-border" />
        </div>

        <Button variant="outline" className="w-full" onClick={handleGoogle}>
          Продолжить с Google
        </Button>
      </div>
    </main>
  );
}
