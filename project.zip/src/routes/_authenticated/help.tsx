import { createFileRoute } from "@tanstack/react-router";
import { SettingsPageShell } from "@/components/bottom-nav";
import { ReportDialog } from "@/components/report-dialog";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const Route = createFileRoute("/_authenticated/help")({
  head: () => ({
    meta: [
      { title: "Помощь — PulsLink" },
      { name: "description", content: "Ответы на вопросы о PulsLink и отправка жалобы на аккаунт, канал, группу или бота." },
      { property: "og:title", content: "Помощь — PulsLink" },
      { property: "og:description", content: "Ответы на вопросы и жалобы в PulsLink." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HelpPage,
});

const FAQ = [
  { q: "Как создать канал?", a: "Откройте вкладку «Каналы» и нажмите «Создать канал»: укажите название, свободный юзернейм, описание и участников." },
  { q: "Что означает галочка?", a: "Синяя галочка — аккаунт или канал подтверждён командой PulsLink. Значок портфеля — бизнес-аккаунт." },
  { q: "Как включить 2FA?", a: "Настройки → Аккаунт → раздел двухфакторной аутентификации, отсканируйте QR-код в приложении-аутентификаторе." },
  { q: "Как пожаловаться?", a: "Кнопка с флажком рядом с аккаунтом, каналом, группой или ботом, либо кнопка ниже на этой странице." },
];

function HelpPage() {
  return (
    <SettingsPageShell title="Помощь">
      <section className="surface-panel rounded-3xl border border-border px-4 py-2">
        <Accordion type="single" collapsible>
          {FAQ.map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left text-[15px]">{f.q}</AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      <ReportDialog
        targetType="user"
        targetLabel="Обращение в поддержку PulsLink"
        trigger={<Button className="w-full">Пожаловаться / задать вопрос</Button>}
      />
    </SettingsPageShell>
  );
}
