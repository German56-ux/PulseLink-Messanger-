import { createFileRoute } from "@tanstack/react-router";
import { SettingsPageShell } from "@/components/bottom-nav";

export const Route = createFileRoute("/_authenticated/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Политика конфиденциальности — PulsLink" },
      { name: "description", content: "Как PulsLink обрабатывает и защищает данные пользователей." },
      { property: "og:title", content: "Политика конфиденциальности — PulsLink" },
      { property: "og:description", content: "Как PulsLink обрабатывает и защищает данные пользователей." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PolicyPage,
});

function PolicyPage() {
  return (
    <SettingsPageShell title="Политика конфиденциальности">
      <section className="surface-panel space-y-3 rounded-3xl border border-border p-4 text-sm text-muted-foreground">
        <p>PulsLink хранит минимально необходимые данные: профиль, участие в чатах и сообщения.</p>
        <p>Сообщения и файлы доступны только участникам чата; вложения выдаются по временным защищённым ссылкам.</p>
        <p>Настройки приватности определяют, кто видит время захода, аватар и может писать вам.</p>
        <p>Жалобы рассматривает команда PulsLink; нарушители получают ограничение или блокировку аккаунта.</p>
        <p>Вы можете в любой момент удалить свои сообщения и выйти из чатов.</p>
      </section>
    </SettingsPageShell>
  );
}
