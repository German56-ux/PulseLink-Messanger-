import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Send, Plus, ArrowUp, Coins, Repeat, Percent, LayoutGrid } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { BottomNav } from "@/components/bottom-nav";
import { useWallet, totalRub, formatRub } from "@/lib/wallet";

export const Route = createFileRoute("/_authenticated/wallet")({
  head: () => ({
    meta: [
      { title: "Кошелёк — PulsLink" },
      { name: "description", content: "Встроенный кошелёк PulsLink: баланс, токены, переводы и пополнение." },
      { property: "og:title", content: "Кошелёк — PulsLink" },
      { property: "og:description", content: "Встроенный кошелёк PulsLink: баланс, токены, переводы и пополнение." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: WalletPage,
});

function WalletPage() {
  const { tokens, update } = useWallet();
  const [tab, setTab] = useState<"wallet" | "defi">("wallet");
  const total = totalRub(tokens);

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl px-4 py-6 space-y-6">
        <header className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3">
          <Button asChild variant="ghost" size="icon" aria-label="Назад">
            <Link to="/settings">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <h1 className="truncate font-display text-xl">Кошелёк</h1>
          <div className="flex rounded-full border border-border p-1 text-xs">
            {(["wallet", "defi"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-full px-3 py-1 ${tab === t ? "bg-secondary text-secondary-foreground" : "text-muted-foreground"}`}
              >
                {t === "wallet" ? "Wallet" : "DeFi"}
              </button>
            ))}
          </div>
        </header>

        <section className="surface-panel rounded-3xl border border-border p-6 text-center">
          <p className="text-xs text-muted-foreground">PLS·{tokens[0]?.symbol ?? "PULS"}···kMdW</p>
          <p className="mt-2 font-display text-4xl">{formatRub(total)}</p>
          <div className="mt-6 grid grid-cols-3 gap-3">
            <AmountDialog
              title="Перевести"
              icon={<Send className="size-4" />}
              action={(v) => {
                if (v > tokens[0].amount) {
                  toast.error("Недостаточно средств");
                  return false;
                }
                update("PULS", -v);
                toast.success(`Переведено ${v} PULS`);
                return true;
              }}
            />
            <AmountDialog
              title="Пополнить"
              icon={<Plus className="size-4" />}
              action={(v) => {
                update("PULS", v);
                toast.success(`Пополнено на ${v} PULS`);
                return true;
              }}
            />
            <AmountDialog
              title="Вывести"
              icon={<ArrowUp className="size-4" />}
              action={(v) => {
                if (v > tokens[0].amount) {
                  toast.error("Недостаточно средств");
                  return false;
                }
                update("PULS", -v);
                toast.success(`Выведено ${v} PULS`);
                return true;
              }}
            />
          </div>
        </section>

        <section className="surface-panel overflow-hidden rounded-3xl border border-border">
          <p className="px-4 pt-4 pb-2 text-sm text-primary-glow">Токены</p>
          <div className="divide-y divide-border">
            {tokens.map((t) => (
              <div key={t.symbol} className="flex items-center gap-3 px-4 py-3">
                <span className="tile tile-blue">
                  <Coins className="size-4" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px]">{t.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {t.amount.toLocaleString("ru-RU")} {t.symbol}
                  </p>
                </div>
                <p className="shrink-0 text-sm">{formatRub(t.amount * t.rate)}</p>
              </div>
            ))}
          </div>
        </section>

        {tab === "defi" ? (
          <section className="surface-panel grid grid-cols-4 gap-2 rounded-3xl border border-border p-4 text-center text-xs text-muted-foreground">
            {[
              { icon: Coins, label: "DeFi" },
              { icon: Repeat, label: "Обмен" },
              { icon: Percent, label: "Доход" },
              { icon: LayoutGrid, label: "Приложения" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-1">
                <span className="grid size-9 place-items-center rounded-full bg-secondary text-secondary-foreground">
                  <Icon className="size-4" />
                </span>
                {label}
              </div>
            ))}
          </section>
        ) : null}
      </div>
      <BottomNav />
    </main>
  );
}

function AmountDialog({
  title,
  icon,
  action,
}: {
  title: string;
  icon: React.ReactNode;
  action: (value: number) => boolean;
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");

  function submit() {
    const v = Number(value.replace(",", "."));
    if (!Number.isFinite(v) || v <= 0 || v > 1_000_000) {
      toast.error("Введите сумму от 0 до 1 000 000");
      return;
    }
    if (action(v)) {
      setOpen(false);
      setValue("");
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="secondary" className="h-auto flex-col gap-1 py-3 text-xs">
          {icon}
          {title}
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <Input
          inputMode="decimal"
          maxLength={12}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Сумма в PULS"
        />
        <DialogFooter>
          <Button onClick={submit}>Подтвердить</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
