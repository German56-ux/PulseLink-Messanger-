import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Radio, Plus, Search, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";
import { useSession } from "@/hooks/use-session";
import {
  searchChannels,
  createChannel,
  joinChannel,
  isUsernameAvailable,
  searchUsers,
  USERNAME_RE,
  type Chat,
  type Profile,
} from "@/lib/pulslink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { BottomNav } from "@/components/bottom-nav";
import { VerifiedBadge } from "@/components/verified-badge";
import { ReportDialog } from "@/components/report-dialog";

export const Route = createFileRoute("/_authenticated/channels")({
  head: () => ({
    meta: [
      { title: "Каналы — PulsLink" },
      { name: "description", content: "Публичные каналы PulsLink: поиск, подписка и создание своего канала." },
      { property: "og:title", content: "Каналы — PulsLink" },
      { property: "og:description", content: "Публичные каналы PulsLink: поиск, подписка и создание своего канала." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChannelsPage,
});

function ChannelsPage() {
  const { user } = useSession();
  const meId = user?.id ?? "";
  const [term, setTerm] = useState("");
  const queryClient = useQueryClient();

  const channelsQuery = useQuery({
    queryKey: ["channels", term],
    queryFn: () => searchChannels(term),
  });

  async function join(chat: Chat) {
    try {
      await joinChannel(chat.id, meId);
      toast.success(`Вы подписались на ${chat.title}`);
      queryClient.invalidateQueries({ queryKey: ["chats", meId] });
    } catch {
      toast.error("Не удалось подписаться");
    }
  }

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-6">
        <div className="flex items-center gap-2">
          <h1 className="font-display text-2xl">Каналы</h1>
          <div className="ml-auto">
            <CreateChannelDialog meId={meId} onCreated={() => channelsQuery.refetch()} />
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Поиск каналов"
            className="pl-9"
            maxLength={60}
          />
        </div>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          {channelsQuery.isLoading ? (
            <p className="p-4 text-sm text-muted-foreground">Загрузка…</p>
          ) : (channelsQuery.data ?? []).length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">Каналы не найдены</p>
          ) : (
            (channelsQuery.data ?? []).map((chat) => (
              <div key={chat.id} className="flex items-center gap-3 px-4 py-3">
                <Avatar className="size-11">
                  <AvatarFallback className="gradient-pulse text-primary-foreground">
                    {(chat.title ?? "К").slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <p className="truncate font-medium">{chat.title}</p>
                    <VerifiedBadge verified={chat.is_verified} business={chat.is_business} />
                  </div>
                  <p className="truncate text-xs text-muted-foreground">@{chat.username}</p>
                  {chat.description ? (
                    <p className="truncate text-xs text-muted-foreground">{chat.description}</p>
                  ) : null}
                </div>
                <ReportDialog
                  targetType="channel"
                  targetId={chat.id}
                  targetLabel={`@${chat.username ?? chat.title}`}
                />
                <Button size="sm" onClick={() => join(chat)}>
                  Подписаться
                </Button>
              </div>
            ))
          )}
        </section>
      </div>
      <BottomNav />
    </main>
  );
}

function CreateChannelDialog({ meId, onCreated }: { meId: string; onCreated: () => void }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [username, setUsername] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [status, setStatus] = useState<"idle" | "checking" | "free" | "taken" | "invalid">("idle");
  const [term, setTerm] = useState("");
  const [results, setResults] = useState<Profile[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const value = username.trim();
    if (!value) {
      setStatus("idle");
      return;
    }
    if (!USERNAME_RE.test(value)) {
      setStatus("invalid");
      return;
    }
    setStatus("checking");
    let active = true;
    const t = setTimeout(async () => {
      try {
        const free = await isUsernameAvailable(value);
        if (active) setStatus(free ? "free" : "taken");
      } catch {
        if (active) setStatus("idle");
      }
    }, 400);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [username]);

  useEffect(() => {
    let active = true;
    const t = setTimeout(async () => {
      if (term.trim().length < 2) {
        setResults([]);
        return;
      }
      const rows = await searchUsers(term, meId);
      if (active) setResults(rows);
    }, 250);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [term, meId]);

  async function create() {
    if (!title.trim()) {
      toast.error("Введите название канала");
      return;
    }
    if (status !== "free") {
      toast.error("Укажите свободный юзернейм");
      return;
    }
    setBusy(true);
    try {
      await createChannel(meId, {
        title,
        username: username.trim(),
        description,
        isPublic,
        memberIds: selected,
      });
      toast.success("Канал создан");
      setOpen(false);
      setTitle("");
      setUsername("");
      setDescription("");
      setSelected([]);
      onCreated();
    } catch (e) {
      toast.error(
        e instanceof Error && e.message === "USERNAME_TAKEN"
          ? "Этот юзернейм уже занят"
          : "Не удалось создать канал",
      );
    }
    setBusy(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gradient-pulse text-primary-foreground" size="sm">
          <Plus className="size-4" /> Создать канал
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Radio className="size-4" /> Новый канал
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Название канала"
            maxLength={60}
          />
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">@</span>
              <Input
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
                placeholder="username канала"
                maxLength={32}
              />
              {status === "checking" ? <Loader2 className="size-4 animate-spin" /> : null}
              {status === "free" ? <Check className="size-4 text-emerald-400" /> : null}
              {status === "taken" || status === "invalid" ? <X className="size-4 text-destructive" /> : null}
            </div>
            <p className="text-xs text-muted-foreground">
              {status === "taken"
                ? "Юзернейм занят"
                : status === "invalid"
                  ? "5–32 символа: латиница, цифры и _"
                  : status === "free"
                    ? "Юзернейм свободен"
                    : "Ссылка канала: pulslink.app/" + (username || "username")}
            </p>
          </div>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Описание канала"
            maxLength={300}
          />
          <label className="flex items-center justify-between rounded-xl border border-border px-3 py-2 text-sm">
            Публичный канал
            <Switch checked={isPublic} onCheckedChange={setIsPublic} />
          </label>

          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Участники (необязательно)</p>
            <Input
              value={term}
              onChange={(e) => setTerm(e.target.value)}
              placeholder="Поиск по никнейму"
              maxLength={60}
            />
            <div className="max-h-48 space-y-1 overflow-y-auto">
              {results.map((p) => (
                <div key={p.id} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-accent">
                  <Avatar className="size-9">
                    <AvatarFallback className="gradient-pulse text-primary-foreground">
                      {(p.display_name || p.username).slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">{p.display_name || p.username}</p>
                    <p className="truncate text-xs text-muted-foreground">@{p.username}</p>
                  </div>
                  <Checkbox
                    checked={selected.includes(p.id)}
                    onCheckedChange={(v) =>
                      setSelected((s) => (v ? [...s, p.id] : s.filter((x) => x !== p.id)))
                    }
                  />
                </div>
              ))}
            </div>
          </div>

          <Button className="w-full" onClick={create} disabled={busy}>
            Создать канал
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
