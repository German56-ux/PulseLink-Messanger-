import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Star, Zap, Upload, Sparkles, BadgeCheck, Palette } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { BottomNav } from "@/components/bottom-nav";
import { usePremium } from "@/lib/wallet";

export const Route = createFileRoute("/_authenticated/premium")({
  head: () => ({
    meta: [
      { title: "PulsLink Premium — расширенные возможности" },
      { name: "description", content: "Большие файлы, ускоренная загрузка, уникальные значки и оформление в PulsLink Premium." },
      { property: "og:title", content: "PulsLink Premium" },
      { property: "og:description", content: "Большие файлы, ускоренная загрузка, уникальные значки и оформление." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PremiumPage,
});

const perks = [
  { icon: Upload, tile: "tile-violet", title: "Файлы до 4 ГБ", text: "Отправляйте большие вложения без сжатия" },
  { icon: Zap, tile: "tile-orange", title: "Быстрая загрузка", text: "Медиа скачивается на максимальной скорости" },
  { icon: BadgeCheck, tile: "tile-blue", title: "Значок Premium", text: "Отметка рядом с вашим именем" },
  { icon: Sparkles, tile: "tile-cyan", title: "Анимированные реакции", text: "Эксклюзивные эмодзи и стикеры" },
  { icon: Palette, tile: "tile-green", title: "Оформление чатов", text: "Уникальные обои и цвета" },
];

function PremiumPage() {
  const { premium, toggle } = usePremium();

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl space-y-6 px-4 py-6">
        <header className="flex items-center gap-3">
          <Button asChild variant="ghost" size="icon" aria-label="Назад">
            <Link to="/settings">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <h1 className="font-display text-xl">PulsLink Premium</h1>
        </header>

        <section className="surface-panel flex flex-col items-center gap-3 rounded-3xl border border-border p-8 text-center">
          <span className="gradient-pulse grid size-16 place-items-center rounded-3xl text-primary-foreground">
            <Star className="size-8" />
          </span>
          <h2 className="font-display text-2xl">Больше возможностей</h2>
          <p className="text-sm text-muted-foreground">
            Подписка открывает эксклюзивные функции и поддерживает развитие PulsLink.
          </p>
        </section>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          {perks.map(({ icon: Icon, tile, title, text }) => (
            <div key={title} className="flex items-center gap-3 px-4 py-3">
              <span className={`tile ${tile}`}>
                <Icon className="size-4" />
              </span>
              <div className="min-w-0">
                <p className="truncate text-[15px]">{title}</p>
                <p className="truncate text-xs text-muted-foreground">{text}</p>
              </div>
            </div>
          ))}
        </section>

        {premium ? (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              toggle(false);
              toast.success("Подписка отключена");
            }}
          >
            Отключить Premium
          </Button>
        ) : (
          <Button
            className="w-full"
            onClick={() => {
              toggle(true);
              toast.success("PulsLink Premium активирован");
            }}
          >
            Подключить за 299 ₽ / мес
          </Button>
        )}
      </div>
      <BottomNav />
    </main>
  );
}
