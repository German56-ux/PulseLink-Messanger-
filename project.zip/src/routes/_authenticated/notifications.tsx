import { createFileRoute } from "@tanstack/react-router";
import { SettingsPageShell } from "@/components/bottom-nav";
import { usePrefs } from "@/lib/prefs";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({
    meta: [
      { title: "Уведомления — PulsLink" },
      { name: "description", content: "Звуки, счётчик сообщений и уведомления групп в PulsLink." },
      { property: "og:title", content: "Уведомления — PulsLink" },
      { property: "og:description", content: "Звуки, счётчик сообщений и уведомления групп в PulsLink." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const { prefs, update } = usePrefs();
  const rows = [
    { key: "notifySound" as const, title: "Звук уведомлений" },
    { key: "notifyBadge" as const, title: "Счётчик непрочитанных" },
    { key: "notifyGroups" as const, title: "Уведомления в группах и каналах" },
  ];
  return (
    <SettingsPageShell title="Уведомления">
      <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
        {rows.map((r) => (
          <label key={r.key} className="flex items-center justify-between px-4 py-3 text-[15px]">
            {r.title}
            <Switch checked={prefs[r.key]} onCheckedChange={(v) => update(r.key, v)} />
          </label>
        ))}
      </section>
    </SettingsPageShell>
  );
}
