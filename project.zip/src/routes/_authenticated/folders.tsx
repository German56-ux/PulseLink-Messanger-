import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Trash2, Plus } from "lucide-react";
import { SettingsPageShell } from "@/components/bottom-nav";
import { usePrefs } from "@/lib/prefs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/folders")({
  head: () => ({
    meta: [
      { title: "Папки с чатами — PulsLink" },
      { name: "description", content: "Сортируйте чаты PulsLink по папкам: личное, работа и свои категории." },
      { property: "og:title", content: "Папки с чатами — PulsLink" },
      { property: "og:description", content: "Сортируйте чаты PulsLink по папкам." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FoldersPage,
});

function FoldersPage() {
  const { prefs, update } = usePrefs();
  const [name, setName] = useState("");

  return (
    <SettingsPageShell title="Папки с чатами">
      <div className="flex gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Название папки" maxLength={30} />
        <Button
          onClick={() => {
            const v = name.trim();
            if (!v || prefs.folders.includes(v)) return;
            update("folders", [...prefs.folders, v]);
            setName("");
          }}
        >
          <Plus className="size-4" />
        </Button>
      </div>
      <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
        {prefs.folders.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">Папок пока нет</p>
        ) : (
          prefs.folders.map((f) => (
            <div key={f} className="flex items-center gap-3 px-4 py-3">
              <span className="flex-1 text-[15px]">{f}</span>
              <button
                aria-label={`Удалить папку ${f}`}
                onClick={() => update("folders", prefs.folders.filter((x) => x !== f))}
              >
                <Trash2 className="size-4 text-muted-foreground" />
              </button>
            </div>
          ))
        )}
      </section>
    </SettingsPageShell>
  );
}
