import { createFileRoute } from "@tanstack/react-router";
import { Laptop, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { SettingsPageShell } from "@/components/bottom-nav";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/devices")({
  head: () => ({
    meta: [
      { title: "Устройства — PulsLink" },
      { name: "description", content: "Активные сеансы PulsLink и завершение сессий на других устройствах." },
      { property: "og:title", content: "Устройства — PulsLink" },
      { property: "og:description", content: "Активные сеансы PulsLink и завершение сессий." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DevicesPage,
});

function DevicesPage() {
  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
  const isMobile = /Mobi|Android|iPhone/i.test(ua);

  async function signOutOthers() {
    const { error } = await supabase.auth.signOut({ scope: "others" });
    if (error) toast.error("Не удалось завершить сеансы");
    else toast.success("Другие сеансы завершены");
  }

  return (
    <SettingsPageShell title="Устройства">
      <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <span className="tile tile-cyan">
            {isMobile ? <Smartphone className="size-4" /> : <Laptop className="size-4" />}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[15px]">Текущее устройство</p>
            <p className="truncate text-xs text-muted-foreground">{ua || "Неизвестно"}</p>
          </div>
          <span className="text-xs text-primary-glow">активно</span>
        </div>
      </section>
      <Button variant="destructive" className="w-full" onClick={signOutOthers}>
        Завершить все другие сеансы
      </Button>
    </SettingsPageShell>
  );
}
