import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Shield, Ban, UserCheck, BadgeCheck, Briefcase } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Админ-панель — PulsLink" },
      { name: "description", content: "Управление пользователями, ролями, галочками и жалобами в PulsLink." },
      { property: "og:title", content: "Админ-панель — PulsLink" },
      { property: "og:description", content: "Управление пользователями, ролями, галочками и жалобами." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPage,
});

type Row = {
  id: string;
  username: string;
  display_name: string | null;
  is_banned: boolean;
  is_verified: boolean;
  is_business: boolean;
  created_at: string;
  roles: string[];
};

function AdminPage() {
  const { user } = useSession();
  const meId = user?.id ?? "";
  const queryClient = useQueryClient();
  const [term, setTerm] = useState("");

  const adminQuery = useQuery({
    queryKey: ["is-admin", meId],
    queryFn: async () => {
      const { data } = await supabase.rpc("has_role", { _user_id: meId, _role: "admin" });
      return !!data;
    },
    enabled: !!meId,
  });

  const reportsQuery = useQuery({
    queryKey: ["admin-reports"],
    queryFn: async () => {
      const { data } = await supabase
        .from("reports")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);
      return data ?? [];
    },
    enabled: adminQuery.data === true,
  });

  async function resolveReport(id: string) {
    const { error } = await supabase.from("reports").update({ status: "resolved" }).eq("id", id);
    if (error) toast.error("Не удалось обновить жалобу");
    queryClient.invalidateQueries({ queryKey: ["admin-reports"] });
  }

  const usersQuery = useQuery({
    queryKey: ["admin-users"],
    queryFn: async (): Promise<Row[]> => {
      const [{ data: profiles }, { data: roles }] = await Promise.all([
        supabase
          .from("profiles")
          .select("id, username, display_name, is_banned, is_verified, is_business, created_at")
          .order("created_at", { ascending: false })
          .limit(200),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      return (profiles ?? []).map((p) => ({
        ...p,
        roles: (roles ?? []).filter((r) => r.user_id === p.id).map((r) => r.role as string),
      }));
    },
    enabled: adminQuery.data === true,
  });

  async function toggleBan(row: Row) {
    const { error } = await supabase.from("profiles").update({ is_banned: !row.is_banned }).eq("id", row.id);
    if (error) toast.error("Недостаточно прав");
    else toast.success(row.is_banned ? "Пользователь разблокирован" : "Пользователь заблокирован");
    queryClient.invalidateQueries({ queryKey: ["admin-users"] });
  }

  async function toggleFlag(row: Row, field: "is_verified" | "is_business") {
    const patch =
      field === "is_verified" ? { is_verified: !row.is_verified } : { is_business: !row.is_business };
    const { error } = await supabase.from("profiles").update(patch).eq("id", row.id);
    if (error) toast.error("Недостаточно прав");
    else
      toast.success(
        field === "is_verified"
          ? row.is_verified
            ? "Галочка снята"
            : "Аккаунт подтверждён командой PulsLink"
          : row.is_business
            ? "Бизнес-статус снят"
            : "Бизнес-аккаунт включён",
      );
    queryClient.invalidateQueries({ queryKey: ["admin-users"] });
  }

  async function toggleRole(row: Row, role: "admin" | "moderator") {
    const has = row.roles.includes(role);
    const { error } = has
      ? await supabase.from("user_roles").delete().eq("user_id", row.id).eq("role", role)
      : await supabase.from("user_roles").insert({ user_id: row.id, role });
    if (error) toast.error("Недостаточно прав");
    queryClient.invalidateQueries({ queryKey: ["admin-users"] });
  }

  if (adminQuery.isLoading) {
    return <main className="chat-canvas min-h-screen p-6 text-sm text-muted-foreground">Проверка доступа…</main>;
  }

  if (!adminQuery.data) {
    return (
      <main className="chat-canvas flex min-h-screen flex-col items-center justify-center gap-4 p-6 text-center">
        <h1 className="font-display text-2xl">Доступ только для администраторов</h1>
        <Button asChild variant="outline">
          <Link to="/chats">Вернуться в чаты</Link>
        </Button>
      </main>
    );
  }

  const rows = (usersQuery.data ?? []).filter((r) =>
    `${r.username} ${r.display_name ?? ""}`.toLowerCase().includes(term.trim().toLowerCase()),
  );

  return (
    <main className="chat-canvas min-h-screen px-4 py-6">
      <div className="mx-auto w-full max-w-4xl space-y-6">
        <header className="flex items-center gap-3">
          <Button asChild variant="ghost" size="icon" aria-label="Назад">
            <Link to="/chats">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <Shield className="size-5 text-primary-glow" />
          <h1 className="font-display text-2xl">Админ-панель</h1>
        </header>

        <Input
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="Поиск пользователей"
          maxLength={60}
        />

        <div className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          {rows.length === 0 ? (
            <p className="p-5 text-sm text-muted-foreground">Пользователи не найдены</p>
          ) : (
            rows.map((row) => (
              <div key={row.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{row.display_name || row.username}</p>
                  <p className="truncate text-xs text-muted-foreground">@{row.username}</p>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {row.roles.map((r) => (
                    <Badge key={r} variant="secondary">
                      {r}
                    </Badge>
                  ))}
                  {row.is_verified ? <Badge variant="secondary">подтверждён</Badge> : null}
                  {row.is_business ? <Badge variant="secondary">бизнес</Badge> : null}
                  {row.is_banned ? <Badge variant="destructive">заблокирован</Badge> : null}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    aria-label="Галочка подтверждения"
                    onClick={() => toggleFlag(row, "is_verified")}
                  >
                    <BadgeCheck className="size-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    aria-label="Бизнес-аккаунт"
                    onClick={() => toggleFlag(row, "is_business")}
                  >
                    <Briefcase className="size-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => toggleRole(row, "moderator")}>
                    {row.roles.includes("moderator") ? "Снять модератора" : "Модератор"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => toggleRole(row, "admin")}>
                    {row.roles.includes("admin") ? "Снять админа" : "Админ"}
                  </Button>
                  <Button
                    size="sm"
                    variant={row.is_banned ? "secondary" : "destructive"}
                    onClick={() => toggleBan(row)}
                  >
                    {row.is_banned ? <UserCheck className="size-4" /> : <Ban className="size-4" />}
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>

        <section className="space-y-3">
          <h2 className="font-display text-xl">Жалобы</h2>
          <div className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
            {(reportsQuery.data ?? []).length === 0 ? (
              <p className="p-5 text-sm text-muted-foreground">Жалоб нет</p>
            ) : (
              (reportsQuery.data ?? []).map((r) => (
                <div key={r.id} className="flex flex-wrap items-center gap-3 p-4">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">
                      {r.target_type}: {r.target_label ?? r.target_id ?? "—"}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {r.reason}
                      {r.details ? ` — ${r.details}` : ""}
                    </p>
                  </div>
                  <Badge variant={r.status === "resolved" ? "secondary" : "destructive"}>{r.status}</Badge>
                  {r.status !== "resolved" ? (
                    <Button size="sm" variant="outline" onClick={() => resolveReport(r.id)}>
                      Решено
                    </Button>
                  ) : null}
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
