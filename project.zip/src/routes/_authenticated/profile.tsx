import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Settings, Wallet, Star, Pencil, MessageCircle } from "lucide-react";
import { useSession, useAvatarUrl } from "@/hooks/use-session";
import { fetchMyProfile } from "@/lib/pulslink";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { BottomNav, SettingsRow } from "@/components/bottom-nav";
import { VerifiedBadge } from "@/components/verified-badge";
import { usePremium } from "@/lib/wallet";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Профиль — PulsLink" },
      { name: "description", content: "Ваш профиль PulsLink: имя, никнейм, статус Premium и кошелёк." },
      { property: "og:title", content: "Профиль — PulsLink" },
      { property: "og:description", content: "Ваш профиль PulsLink: имя, никнейм, статус Premium и кошелёк." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = useSession();
  const meId = user?.id ?? "";
  const { premium } = usePremium();
  const { data: profile } = useQuery({
    queryKey: ["profile", meId],
    queryFn: () => fetchMyProfile(meId),
    enabled: !!meId,
  });
  const avatar = useAvatarUrl(profile?.avatar_url ?? null);
  const name = profile?.display_name || profile?.username || "Профиль";

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-6">
        <section className="surface-panel flex flex-col items-center gap-3 rounded-3xl border border-border p-6">
          <Avatar className="size-24">
            {avatar ? <AvatarImage src={avatar} alt="Аватар" /> : null}
            <AvatarFallback className="gradient-pulse text-2xl text-primary-foreground">
              {name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <h1 className="flex items-center gap-1.5 font-display text-2xl">
            {name}
            <VerifiedBadge verified={profile?.is_verified} business={profile?.is_business} />
          </h1>
          {profile?.is_verified ? (
            <p className="text-xs text-primary-glow">Подтверждён командой PulsLink</p>
          ) : null}
          <p className="text-sm text-muted-foreground">@{profile?.username ?? "—"}</p>
          {premium ? <p className="text-sm text-primary-glow">PulsLink Premium активен</p> : null}
          {profile?.bio ? <p className="text-center text-sm text-muted-foreground">{profile.bio}</p> : null}
          <div className="flex gap-2">
            <Button asChild size="sm">
              <Link to="/account">
                <Pencil className="size-4" /> Редактировать
              </Link>
            </Button>
            <Button asChild size="sm" variant="outline">
              <Link to="/chats">
                <MessageCircle className="size-4" /> Чаты
              </Link>
            </Button>
          </div>
        </section>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          <Link to="/wallet">
            <SettingsRow icon={Wallet} tile="tile-blue" title="Кошелёк" subtitle="Баланс и переводы" />
          </Link>
          <Link to="/premium">
            <SettingsRow icon={Star} tile="tile-violet" title="PulsLink Premium" subtitle="Расширенные возможности" />
          </Link>
          <Link to="/settings">
            <SettingsRow icon={Settings} tile="tile-cyan" title="Настройки" />
          </Link>
        </section>
      </div>
      <BottomNav />
    </main>
  );
}
