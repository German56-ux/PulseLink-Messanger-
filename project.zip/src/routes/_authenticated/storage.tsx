import { createFileRoute } from "@tanstack/react-router";
import { SettingsPageShell } from "@/components/bottom-nav";
import { usePrefs } from "@/lib/prefs";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/_authenticated/storage")({
  head: () => ({
    meta: [
      { title: "Данные и память — PulsLink" },
      { name: "description", content: "Автозагрузка медиа и использование памяти в PulsLink." },
      { property: "og:title", content: "Данные и память — PulsLink" },
      { property: "og:description", content: "Автозагрузка медиа и использование памяти в PulsLink." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: StoragePage,
});

function StoragePage() {
  const { prefs, update } = usePrefs();
  return (
    <SettingsPageShell title="Данные и память">
      <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
        <label className="flex items-center justify-between px-4 py-3 text-[15px]">
          Автозагрузка фото
          <Switch checked={prefs.autoDownloadPhotos} onCheckedChange={(v) => update("autoDownloadPhotos", v)} />
        </label>
        <label className="flex items-center justify-between px-4 py-3 text-[15px]">
          Автозагрузка видео
          <Switch checked={prefs.autoDownloadVideos} onCheckedChange={(v) => update("autoDownloadVideos", v)} />
        </label>
        <label className="flex items-center justify-between px-4 py-3 text-[15px]">
          Сохранять в галерею
          <Switch checked={prefs.saveToGallery} onCheckedChange={(v) => update("saveToGallery", v)} />
        </label>
      </section>
      <p className="text-xs text-muted-foreground">
        Медиафайлы хранятся в защищённом облаке PulsLink и доступны только участникам чата.
      </p>
    </SettingsPageShell>
  );
}
