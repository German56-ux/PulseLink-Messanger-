import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ShieldCheck, Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useAvatarUrl } from "@/hooks/use-session";
import { fetchMyProfile, uploadFile, type Profile } from "@/lib/pulslink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Separator } from "@/components/ui/separator";

export const Route = createFileRoute("/_authenticated/account")({
  component: AccountPage,
});

const profileSchema = z.object({
  display_name: z.string().trim().min(1, "Укажите имя").max(48),
  username: z.string().trim().min(3, "Минимум 3 символа").max(24).regex(/^[a-zA-Z0-9_]+$/, "Только латиница, цифры и _"),
  bio: z.string().trim().max(280, "Максимум 280 символов"),
});

const PRIVACY = [
  { value: "everyone", label: "Все" },
  { value: "contacts", label: "Только контакты" },
  { value: "nobody", label: "Никто" },
];

function AccountPage() {
  const { user } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const meId = user?.id ?? "";
  const [form, setForm] = useState<Profile | null>(null);
  const [saving, setSaving] = useState(false);

  const profileQuery = useQuery({
    queryKey: ["profile", meId],
    queryFn: () => fetchMyProfile(meId),
    enabled: !!meId,
  });

  useEffect(() => {
    if (profileQuery.data) setForm(profileQuery.data as Profile);
  }, [profileQuery.data]);

  const avatar = useAvatarUrl(form?.avatar_url ?? null);

  async function save() {
    if (!form) return;
    const parsed = profileSchema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        display_name: parsed.data.display_name,
        username: parsed.data.username,
        bio: parsed.data.bio,
        privacy_last_seen: form.privacy_last_seen,
        privacy_avatar: form.privacy_avatar,
        privacy_messages: form.privacy_messages,
      })
      .eq("id", meId);
    setSaving(false);
    if (error) {
      toast.error(error.message.includes("duplicate") ? "Никнейм занят" : "Не удалось сохранить");
      return;
    }
    toast.success("Сохранено");
    queryClient.invalidateQueries({ queryKey: ["profile", meId] });
  }

  async function onAvatar(file: File) {
    try {
      const path = await uploadFile(meId, file, "avatars");
      await supabase.from("profiles").update({ avatar_url: path }).eq("id", meId);
      setForm((f) => (f ? { ...f, avatar_url: path } : f));
      toast.success("Аватар обновлён");
    } catch {
      toast.error("Не удалось загрузить аватар");
    }
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <main className="chat-canvas min-h-screen px-4 py-6">
      <div className="mx-auto w-full max-w-2xl space-y-6">
        <header className="flex items-center gap-3">
          <Button asChild variant="ghost" size="icon" aria-label="Назад">
            <Link to="/chats">
              <ArrowLeft className="size-4" />
            </Link>
          </Button>
          <h1 className="font-display text-2xl">Аккаунт</h1>
        </header>

        {!form ? (
          <p className="text-sm text-muted-foreground">Загрузка…</p>
        ) : (
          <>
            <section className="surface-panel space-y-4 rounded-3xl border border-border p-6">
              <div className="flex items-center gap-4">
                <Avatar className="size-16">
                  {avatar ? <AvatarImage src={avatar} alt="Аватар" /> : null}
                  <AvatarFallback className="gradient-pulse text-primary-foreground">
                    {(form.display_name || form.username).slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) onAvatar(f);
                      e.target.value = "";
                    }}
                  />
                  <span className="inline-flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-sm">
                    <Upload className="size-4" /> Загрузить фото
                  </span>
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="display">Имя</Label>
                  <Input
                    id="display"
                    value={form.display_name ?? ""}
                    maxLength={48}
                    onChange={(e) => setForm({ ...form, display_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uname">Никнейм</Label>
                  <Input
                    id="uname"
                    value={form.username ?? ""}
                    maxLength={24}
                    onChange={(e) => setForm({ ...form, username: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bio">О себе</Label>
                <Textarea
                  id="bio"
                  value={form.bio ?? ""}
                  maxLength={280}
                  onChange={(e) => setForm({ ...form, bio: e.target.value })}
                />
              </div>
            </section>

            <section className="surface-panel space-y-4 rounded-3xl border border-border p-6">
              <h2 className="font-display text-lg">Конфиденциальность</h2>
              {(
                [
                  ["privacy_last_seen", "Кто видит время в сети"],
                  ["privacy_avatar", "Кто видит фото профиля"],
                  ["privacy_messages", "Кто может писать мне"],
                ] as const
              ).map(([key, label]) => (
                <div key={key} className="flex items-center justify-between gap-4">
                  <span className="text-sm">{label}</span>
                  <Select
                    value={(form as any)[key]}
                    onValueChange={(v) => setForm({ ...form, [key]: v } as Profile)}
                  >
                    <SelectTrigger className="w-44">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PRIVACY.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
              <Button onClick={save} disabled={saving}>
                {saving ? <Loader2 className="size-4 animate-spin" /> : "Сохранить"}
              </Button>
            </section>

            <TwoFactorSection />

            <Separator />
            <Button variant="outline" onClick={signOut}>
              Выйти из аккаунта
            </Button>
          </>
        )}
      </div>
    </main>
  );
}

function TwoFactorSection() {
  const [factors, setFactors] = useState<{ id: string; status: string }[]>([]);
  const [enroll, setEnroll] = useState<{ id: string; qr: string; secret: string } | null>(null);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const { data } = await supabase.auth.mfa.listFactors();
    setFactors((data?.totp ?? []).map((f) => ({ id: f.id, status: f.status })));
  }

  useEffect(() => {
    refresh();
  }, []);

  async function start() {
    setBusy(true);
    const { data, error } = await supabase.auth.mfa.enroll({
      factorType: "totp",
      friendlyName: `PulsLink ${Date.now()}`,
    });
    setBusy(false);
    if (error || !data) {
      toast.error(error?.message ?? "Не удалось включить 2FA");
      return;
    }
    setEnroll({ id: data.id, qr: data.totp.qr_code, secret: data.totp.secret });
  }

  async function verify() {
    if (!enroll || code.length !== 6) return;
    setBusy(true);
    const { data: challenge, error: cErr } = await supabase.auth.mfa.challenge({ factorId: enroll.id });
    if (cErr || !challenge) {
      setBusy(false);
      toast.error("Ошибка проверки");
      return;
    }
    const { error } = await supabase.auth.mfa.verify({
      factorId: enroll.id,
      challengeId: challenge.id,
      code,
    });
    setBusy(false);
    if (error) {
      toast.error("Неверный код");
      return;
    }
    toast.success("2FA включена");
    setEnroll(null);
    setCode("");
    refresh();
  }

  async function remove(id: string) {
    const { error } = await supabase.auth.mfa.unenroll({ factorId: id });
    if (error) toast.error("Не удалось отключить");
    else toast.success("2FA отключена");
    refresh();
  }

  const active = factors.filter((f) => f.status === "verified");

  return (
    <section className="surface-panel space-y-4 rounded-3xl border border-border p-6">
      <div className="flex items-center gap-2">
        <ShieldCheck className="size-5 text-primary-glow" />
        <h2 className="font-display text-lg">Двухфакторная защита</h2>
      </div>
      <p className="text-sm text-muted-foreground">
        Подтверждение входа кодом из приложения-аутентификатора (Google Authenticator, 1Password и др.).
      </p>

      {active.length > 0 ? (
        <div className="flex items-center gap-3">
          <span className="text-sm text-primary-glow">2FA включена</span>
          <Button variant="outline" size="sm" onClick={() => remove(active[0].id)}>
            Отключить
          </Button>
        </div>
      ) : enroll ? (
        <div className="space-y-4">
          <img src={enroll.qr} alt="QR-код для 2FA" className="size-44 rounded-xl bg-card p-2" />
          <p className="break-all text-xs text-muted-foreground">Ключ: {enroll.secret}</p>
          <InputOTP maxLength={6} value={code} onChange={setCode}>
            <InputOTPGroup>
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <InputOTPSlot key={i} index={i} />
              ))}
            </InputOTPGroup>
          </InputOTP>
          <div className="flex gap-2">
            <Button onClick={verify} disabled={busy || code.length !== 6}>
              Подтвердить
            </Button>
            <Button variant="ghost" onClick={() => setEnroll(null)}>
              Отмена
            </Button>
          </div>
        </div>
      ) : (
        <Button onClick={start} disabled={busy}>
          {busy ? <Loader2 className="size-4 animate-spin" /> : "Включить 2FA"}
        </Button>
      )}
    </section>
  );
}
