import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  User,
  MessageSquare,
  KeyRound,
  Bell,
  Database,
  Folder,
  Laptop,
  Globe,
  Star,
  Wallet,
  HelpCircle,
  ShieldCheck,
  ChevronRight,
} from "lucide-react";
import { useSession, useAvatarUrl } from "@/hooks/use-session";
import { fetchMyProfile } from "@/lib/pulslink";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BottomNav, SettingsRow } from "@/components/bottom-nav";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Настройки — PulsLink" },
      { name: "description", content: "Аккаунт, конфиденциальность, кошелёк и Premium в PulsLink." },
      { property: "og:title", content: "Настройки — PulsLink" },
      { property: "og:description", content: "Аккаунт, конфиденциальность, кошелёк и Premium в PulsLink." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = useSession();
  const meId = user?.id ?? "";
  const { data: profile } = useQuery({
    queryKey: ["profile", meId],
    queryFn: () => fetchMyProfile(meId),
    enabled: !!meId,
  });
  const avatar = useAvatarUrl(profile?.avatar_url ?? null);
  const name = profile?.display_name || profile?.username || "Профиль";

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl px-4 py-6 space-y-4">
        <header className="flex flex-col items-center gap-2 pb-2">
          <Avatar className="size-20">
            {avatar ? <AvatarImage src={avatar} alt="Аватар" /> : null}
            <AvatarFallback className="gradient-pulse text-xl text-primary-foreground">
              {name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <h1 className="font-display text-2xl">{name}</h1>
          <p className="text-sm text-muted-foreground">@{profile?.username ?? "—"}</p>
        </header>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          <Link to="/account">
            <SettingsRow icon={User} tile="tile-blue" title="Аккаунт" subtitle="Имя пользователя, «О себе»" right={<ChevronRight className="size-4 text-muted-foreground" />} />
          </Link>
          <Link to="/account">
            <SettingsRow icon={MessageSquare} tile="tile-orange" title="Настройки чатов" subtitle="Оформление, ночной режим" right={<ChevronRight className="size-4 text-muted-foreground" />} />
          </Link>
          <Link to="/account">
            <SettingsRow icon={KeyRound} tile="tile-green" title="Конфиденциальность" subtitle="Время захода, 2FA, блокировки" right={<ChevronRight className="size-4 text-muted-foreground" />} />
          </Link>
          <SettingsRow icon={Bell} tile="tile-red" title="Уведомления" subtitle="Звуки, счётчик сообщений" />
          <SettingsRow icon={Database} tile="tile-blue" title="Данные и память" subtitle="Настройки загрузки медиафайлов" />
          <SettingsRow icon={Folder} tile="tile-cyan" title="Папки с чатами" subtitle="Сортировка чатов по папкам" />
          <SettingsRow icon={Laptop} tile="tile-cyan" title="Устройства" subtitle="Управление активными сеансами" />
          <SettingsRow icon={Globe} tile="tile-violet" title="Язык" subtitle="Русский" />
        </section>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          <Link to="/premium">
            <SettingsRow icon={Star} tile="tile-violet" title="PulsLink Premium" right={<ChevronRight className="size-4 text-muted-foreground" />} />
          </Link>
          <Link to="/wallet">
            <SettingsRow icon={Wallet} tile="tile-blue" title="Кошелёк" right={<ChevronRight className="size-4 text-muted-foreground" />} />
          </Link>
        </section>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          <p className="px-4 pt-4 pb-1 text-sm text-primary-glow">Помощь</p>
          <SettingsRow icon={HelpCircle} tile="tile-orange" title="Задать вопрос" />
          <SettingsRow icon={ShieldCheck} tile="tile-green" title="Политика конфиденциальности" />
        </section>

        <p className="pb-2 text-center text-xs text-muted-foreground">PulsLink v1.0</p>
      </div>
      <BottomNav />
    </main>
  );
}
