import { createFileRoute } from "@tanstack/react-router";
import { SettingsPageShell } from "@/components/bottom-nav";
import { usePrefs } from "@/lib/prefs";
import { Check } from "lucide-react";

const LANGS = [
  { code: "ru", label: "Русский" },
  { code: "en", label: "English" },
  { code: "uk", label: "Українська" },
  { code: "kk", label: "Қазақша" },
];

export const Route = createFileRoute("/_authenticated/language")({
  head: () => ({
    meta: [
      { title: "Язык — PulsLink" },
      { name: "description", content: "Выбор языка интерфейса PulsLink." },
      { property: "og:title", content: "Язык — PulsLink" },
      { property: "og:description", content: "Выбор языка интерфейса PulsLink." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LanguagePage,
});

function LanguagePage() {
  const { prefs, update } = usePrefs();
  return (
    <SettingsPageShell title="Язык">
      <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
        {LANGS.map((l) => (
          <button
            key={l.code}
            onClick={() => update("language", l.code)}
            className="flex w-full items-center px-4 py-3 text-left text-[15px]"
          >
            {l.label}
            {prefs.language === l.code ? <Check className="ml-auto size-4 text-primary-glow" /> : null}
          </button>
        ))}
      </section>
    </SettingsPageShell>
  );
}
