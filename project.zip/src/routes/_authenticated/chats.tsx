import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Search,
  Send,
  Paperclip,
  Settings,
  Shield,
  Plus,
  Users,
  ArrowLeft,
  Trash2,
  Pencil,
  Check,
  MessageCircle,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/use-session";
import {
  fetchChatList,
  fetchMessages,
  searchUsers,
  startDirectChat,
  createGroupChat,
  uploadFile,
  formatTime,
  formatDay,
  lastSeenLabel,
  type ChatListItem,
  type Message,
  type Profile,
} from "@/lib/pulslink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { useAvatarUrl } from "@/hooks/use-session";

export const Route = createFileRoute("/_authenticated/chats")({
  component: ChatsPage,
});

function Ava({ path, name, size = "size-11" }: { path: string | null; name: string; size?: string }) {
  const url = useAvatarUrl(path);
  return (
    <Avatar className={size}>
      {url ? <AvatarImage src={url} alt={name} /> : null}
      <AvatarFallback className="gradient-pulse text-primary-foreground">
        {name.slice(0, 2).toUpperCase()}
      </AvatarFallback>
    </Avatar>
  );
}

function ChatsPage() {
  const { user } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const meId = user?.id ?? "";
  const [activeId, setActiveId] = useState<string | null>(null);
  const [filter, setFilter] = useState("");
  const [draft, setDraft] = useState("");
  const [editing, setEditing] = useState<Message | null>(null);
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const chatsQuery = useQuery({
    queryKey: ["chats", meId],
    queryFn: () => fetchChatList(meId),
    enabled: !!meId,
  });

  const messagesQuery = useQuery({
    queryKey: ["messages", activeId],
    queryFn: () => fetchMessages(activeId!),
    enabled: !!activeId,
  });

  const isAdminQuery = useQuery({
    queryKey: ["is-admin", meId],
    queryFn: async () => {
      const { data } = await supabase.rpc("has_role", { _user_id: meId, _role: "admin" });
      return !!data;
    },
    enabled: !!meId,
  });

  useEffect(() => {
    if (!meId) return;
    const channel = supabase
      .channel("pulslink-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, (payload) => {
        const row = (payload.new ?? payload.old) as Message;
        queryClient.invalidateQueries({ queryKey: ["chats", meId] });
        if (row?.chat_id) queryClient.invalidateQueries({ queryKey: ["messages", row.chat_id] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_members" }, () => {
        queryClient.invalidateQueries({ queryKey: ["chats", meId] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [meId, queryClient]);

  useEffect(() => {
    const t = setInterval(() => {
      if (meId) supabase.from("profiles").update({ last_seen: new Date().toISOString() }).eq("id", meId).then();
    }, 60_000);
    return () => clearInterval(t);
  }, [meId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messagesQuery.data?.length, activeId]);

  useEffect(() => {
    if (!activeId || !meId) return;
    supabase
      .from("chat_members")
      .update({ last_read_at: new Date().toISOString() })
      .eq("chat_id", activeId)
      .eq("user_id", meId)
      .then(() => queryClient.invalidateQueries({ queryKey: ["chats", meId] }));
  }, [activeId, meId, messagesQuery.data?.length, queryClient]);

  const chats = chatsQuery.data ?? [];
  const visibleChats = useMemo(
    () => chats.filter((c) => c.title.toLowerCase().includes(filter.trim().toLowerCase())),
    [chats, filter],
  );
  const active = chats.find((c) => c.chat.id === activeId) ?? null;

  async function send() {
    const text = draft.trim();
    if (!activeId || (!text && !editing)) return;
    setSending(true);
    if (editing) {
      const { error } = await supabase
        .from("messages")
        .update({ content: text, edited_at: new Date().toISOString() })
        .eq("id", editing.id);
      if (error) toast.error("Не удалось изменить сообщение");
      setEditing(null);
    } else {
      const { error } = await supabase
        .from("messages")
        .insert({ chat_id: activeId, sender_id: meId, content: text });
      if (error) toast.error("Сообщение не отправлено");
    }
    setDraft("");
    setSending(false);
    queryClient.invalidateQueries({ queryKey: ["messages", activeId] });
    queryClient.invalidateQueries({ queryKey: ["chats", meId] });
  }

  async function attach(file: File) {
    if (!activeId) return;
    setSending(true);
    try {
      const path = await uploadFile(meId, file, "attachments");
      const { error } = await supabase.from("messages").insert({
        chat_id: activeId,
        sender_id: meId,
        content: draft.trim(),
        attachment_url: path,
        attachment_type: file.type.startsWith("image/") ? "image" : "file",
      });
      if (error) throw error;
      setDraft("");
      queryClient.invalidateQueries({ queryKey: ["messages", activeId] });
    } catch {
      toast.error("Не удалось загрузить файл");
    }
    setSending(false);
  }

  async function removeMessage(id: string) {
    const { error } = await supabase.from("messages").delete().eq("id", id);
    if (error) toast.error("Не удалось удалить");
    queryClient.invalidateQueries({ queryKey: ["messages", activeId] });
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="chat-canvas flex h-screen overflow-hidden">
      <aside
        className={`flex w-full flex-col border-r border-border bg-sidebar md:w-[340px] ${active ? "hidden md:flex" : "flex"}`}
      >
        <div className="flex items-center gap-2 px-4 py-4">
          <span className="gradient-pulse flex size-9 items-center justify-center rounded-2xl text-primary-foreground">
            <MessageCircle className="size-5" />
          </span>
          <span className="font-display text-lg">PulsLink</span>
          <div className="ml-auto flex items-center gap-1">
            {isAdminQuery.data ? (
              <Button asChild variant="ghost" size="icon" aria-label="Админ-панель">
                <Link to="/admin">
                  <Shield className="size-4" />
                </Link>
              </Button>
            ) : null}
            <Button asChild variant="ghost" size="icon" aria-label="Настройки">
              <Link to="/settings">
                <Settings className="size-4" />
              </Link>
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2 px-4 pb-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Поиск по чатам"
              className="pl-9"
            />
          </div>
          <NewChatDialog meId={meId} onCreated={(id) => { setActiveId(id); chatsQuery.refetch(); }} />
        </div>

        <ScrollArea className="flex-1">
          {chatsQuery.isLoading ? (
            <p className="p-4 text-sm text-muted-foreground">Загрузка…</p>
          ) : visibleChats.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">
              Пока нет чатов. Нажмите «+», чтобы найти собеседника.
            </p>
          ) : (
            visibleChats.map((item) => <ChatRow key={item.chat.id} item={item} active={item.chat.id === activeId} onClick={() => setActiveId(item.chat.id)} />)
          )}
        </ScrollArea>

        <div className="border-t border-border p-3">
          <Button variant="ghost" className="w-full justify-start" onClick={signOut}>
            Выйти
          </Button>
        </div>
      </aside>

      <section className={`flex flex-1 flex-col ${active ? "flex" : "hidden md:flex"}`}>
        {!active ? (
          <div className="flex flex-1 items-center justify-center px-6 text-center text-muted-foreground">
            Выберите чат, чтобы начать общение
          </div>
        ) : (
          <>
            <header className="flex items-center gap-3 border-b border-border bg-card/60 px-4 py-3 backdrop-blur">
              <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setActiveId(null)}>
                <ArrowLeft className="size-4" />
              </Button>
              <Ava path={active.avatarUrl} name={active.title} size="size-10" />
              <div className="min-w-0">
                <p className="truncate font-medium">{active.title}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {active.chat.type === "group"
                    ? `${active.members.length} участников`
                    : lastSeenLabel(active.peer)}
                </p>
              </div>
              {active.chat.type === "group" ? (
                <Badge variant="secondary" className="ml-auto">
                  <Users className="mr-1 size-3" /> Группа
                </Badge>
              ) : null}
            </header>

            <ScrollArea className="flex-1 px-4 py-4">
              <div className="mx-auto flex max-w-3xl flex-col gap-2">
                {(messagesQuery.data ?? []).map((m, idx, arr) => {
                  const prev = arr[idx - 1];
                  const showDay =
                    !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString();
                  return (
                    <div key={m.id}>
                      {showDay ? (
                        <div className="my-3 text-center text-xs text-muted-foreground">
                          {formatDay(m.created_at)}
                        </div>
                      ) : null}
                      <Bubble
                        message={m}
                        mine={m.sender_id === meId}
                        sender={active.members.find((p) => p.id === m.sender_id) ?? null}
                        group={active.chat.type === "group"}
                        onEdit={() => {
                          setEditing(m);
                          setDraft(m.content);
                        }}
                        onDelete={() => removeMessage(m.id)}
                      />
                    </div>
                  );
                })}
                <div ref={bottomRef} />
              </div>
            </ScrollArea>

            <div className="border-t border-border bg-card/60 px-4 py-3 backdrop-blur">
              {editing ? (
                <div className="mx-auto mb-2 flex max-w-3xl items-center gap-2 text-xs text-muted-foreground">
                  <Pencil className="size-3" /> Редактирование
                  <button className="ml-auto underline" onClick={() => { setEditing(null); setDraft(""); }}>
                    отмена
                  </button>
                </div>
              ) : null}
              <div className="mx-auto flex max-w-3xl items-center gap-2">
                <input
                  ref={fileRef}
                  type="file"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) attach(f);
                    e.target.value = "";
                  }}
                />
                <Button variant="ghost" size="icon" onClick={() => fileRef.current?.click()} aria-label="Вложение">
                  <Paperclip className="size-4" />
                </Button>
                <Input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  placeholder="Сообщение…"
                  maxLength={4000}
                />
                <Button onClick={send} disabled={sending} size="icon" aria-label="Отправить">
                  {sending ? <Loader2 className="size-4 animate-spin" /> : editing ? <Check className="size-4" /> : <Send className="size-4" />}
                </Button>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function ChatRow({ item, active, onClick }: { item: ChatListItem; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-sidebar-accent ${active ? "bg-sidebar-accent" : ""}`}
    >
      <Ava path={item.avatarUrl} name={item.title} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate font-medium">{item.title}</p>
          {item.lastMessage ? (
            <span className="ml-auto shrink-0 text-[11px] text-muted-foreground">
              {formatTime(item.lastMessage.created_at)}
            </span>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          <p className="truncate text-sm text-muted-foreground">
            {item.lastMessage?.attachment_url
              ? "Вложение"
              : (item.lastMessage?.content ?? "Нет сообщений")}
          </p>
          {item.unread > 0 ? (
            <Badge className="ml-auto gradient-pulse text-primary-foreground">{item.unread}</Badge>
          ) : null}
        </div>
      </div>
    </button>
  );
}

function Bubble({
  message,
  mine,
  sender,
  group,
  onEdit,
  onDelete,
}: {
  message: Message;
  mine: boolean;
  sender: Profile | null;
  group: boolean;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const attachment = useAvatarUrl(message.attachment_url);
  return (
    <div className={`group flex ${mine ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${mine ? "bg-bubble-out text-bubble-out-foreground" : "bg-bubble-in text-bubble-in-foreground"}`}
      >
        {group && !mine ? (
          <p className="mb-1 text-xs font-medium text-primary-glow">
            {sender?.display_name || sender?.username || "Участник"}
          </p>
        ) : null}
        {attachment ? (
          message.attachment_type === "image" ? (
            <img src={attachment} alt="Вложение" loading="lazy" className="mb-2 max-h-72 rounded-xl" />
          ) : (
            <a href={attachment} target="_blank" rel="noreferrer" className="mb-2 block underline">
              Скачать файл
            </a>
          )
        ) : null}
        {message.content ? <p className="whitespace-pre-wrap break-words">{message.content}</p> : null}
        <div className="mt-1 flex items-center gap-2 text-[10px] opacity-70">
          <span>{formatTime(message.created_at)}</span>
          {message.edited_at ? <span>изменено</span> : null}
          {mine ? (
            <span className="ml-1 hidden gap-1 group-hover:flex">
              <button onClick={onEdit} aria-label="Изменить">
                <Pencil className="size-3" />
              </button>
              <button onClick={onDelete} aria-label="Удалить">
                <Trash2 className="size-3" />
              </button>
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function NewChatDialog({ meId, onCreated }: { meId: string; onCreated: (chatId: string) => void }) {
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState("");
  const [results, setResults] = useState<Profile[]>([]);
  const [groupMode, setGroupMode] = useState(false);
  const [groupTitle, setGroupTitle] = useState("");
  const [selected, setSelected] = useState<string[]>([]);

  useEffect(() => {
    let active = true;
    const t = setTimeout(async () => {
      if (term.trim().length < 2) {
        setResults([]);
        return;
      }
      const rows = await searchUsers(term, meId);
      if (active) setResults(rows);
    }, 250);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [term, meId]);

  async function openDirect(peer: Profile) {
    try {
      const id = await startDirectChat(meId, peer.id);
      onCreated(id);
      setOpen(false);
    } catch {
      toast.error("Не удалось создать чат");
    }
  }

  async function makeGroup() {
    if (!groupTitle.trim() || selected.length === 0) {
      toast.error("Укажите название и участников");
      return;
    }
    try {
      const id = await createGroupChat(meId, groupTitle.trim().slice(0, 60), selected);
      onCreated(id);
      setOpen(false);
      setGroupMode(false);
      setSelected([]);
      setGroupTitle("");
    } catch {
      toast.error("Не удалось создать группу");
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" className="gradient-pulse text-primary-foreground" aria-label="Новый чат">
          <Plus className="size-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{groupMode ? "Новая группа" : "Новый чат"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {groupMode ? (
            <Input
              value={groupTitle}
              onChange={(e) => setGroupTitle(e.target.value)}
              placeholder="Название группы"
              maxLength={60}
            />
          ) : null}
          <Input
            value={term}
            onChange={(e) => setTerm(e.target.value)}
            placeholder="Поиск по никнейму или имени"
            maxLength={60}
          />
          <div className="max-h-64 space-y-1 overflow-y-auto">
            {results.map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-accent">
                <Ava path={p.avatar_url} name={p.display_name || p.username} size="size-9" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.display_name || p.username}</p>
                  <p className="truncate text-xs text-muted-foreground">@{p.username}</p>
                </div>
                {groupMode ? (
                  <Checkbox
                    checked={selected.includes(p.id)}
                    onCheckedChange={(v) =>
                      setSelected((s) => (v ? [...s, p.id] : s.filter((x) => x !== p.id)))
                    }
                  />
                ) : (
                  <Button size="sm" variant="secondary" onClick={() => openDirect(p)}>
                    Написать
                  </Button>
                )}
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => setGroupMode((v) => !v)}>
              {groupMode ? "Личный чат" : "Создать группу"}
            </Button>
            {groupMode ? (
              <Button className="flex-1" onClick={makeGroup}>
                Создать
              </Button>
            ) : null}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
