import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search, Loader2, UserPlus } from "lucide-react";
import { useSession } from "@/hooks/use-session";
import { searchUsers, startDirectChat, type Profile } from "@/lib/pulslink";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { BottomNav } from "@/components/bottom-nav";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/contacts")({
  head: () => ({
    meta: [
      { title: "Контакты — PulsLink" },
      { name: "description", content: "Найдите людей в PulsLink и начните личную переписку." },
      { property: "og:title", content: "Контакты — PulsLink" },
      { property: "og:description", content: "Найдите людей в PulsLink и начните личную переписку." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ContactsPage,
});

function ContactsPage() {
  const { user } = useSession();
  const meId = user?.id ?? "";
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState<string | null>(null);

  const { data: results = [], isFetching } = useQuery({
    queryKey: ["contacts-search", q, meId],
    queryFn: () => searchUsers(q, meId),
    enabled: !!meId && q.trim().length >= 2,
  });

  async function open(peer: Profile) {
    setBusy(peer.id);
    try {
      await startDirectChat(meId, peer.id);
      navigate({ to: "/chats" });
    } catch {
      toast.error("Не удалось открыть чат");
    } finally {
      setBusy(null);
    }
  }

  return (
    <main className="chat-canvas min-h-screen pb-24">
      <div className="mx-auto w-full max-w-2xl space-y-4 px-4 py-6">
        <h1 className="font-display text-2xl">Контакты</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск по имени или @нику"
            className="pl-9"
            maxLength={40}
          />
        </div>

        <section className="surface-panel divide-y divide-border overflow-hidden rounded-3xl border border-border">
          {q.trim().length < 2 ? (
            <p className="p-4 text-sm text-muted-foreground">Введите минимум 2 символа для поиска.</p>
          ) : isFetching ? (
            <p className="flex items-center gap-2 p-4 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" /> Поиск…
            </p>
          ) : results.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground">Никого не найдено.</p>
          ) : (
            results.map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-3">
                <Avatar className="size-10">
                  <AvatarFallback className="gradient-pulse text-primary-foreground">
                    {(p.display_name || p.username).slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px]">{p.display_name || p.username}</p>
                  <p className="truncate text-xs text-muted-foreground">@{p.username}</p>
                </div>
                <Button size="sm" onClick={() => open(p)} disabled={busy === p.id}>
                  {busy === p.id ? <Loader2 className="size-4 animate-spin" /> : <UserPlus className="size-4" />}
                </Button>
              </div>
            ))
          )}
        </section>
      </div>
      <BottomNav />
    </main>
  );
}
