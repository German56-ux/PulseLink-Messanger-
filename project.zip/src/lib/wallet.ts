import { useCallback, useEffect, useState } from "react";

export type Token = { symbol: string; name: string; amount: number; rate: number };

const WALLET_KEY = "pulslink.wallet";
const PREMIUM_KEY = "pulslink.premium";

export const defaultTokens: Token[] = [
  { symbol: "PULS", name: "Puls", amount: 1250, rate: 0.0009 },
  { symbol: "USDT", name: "USDT", amount: 0, rate: 90 },
  { symbol: "TON", name: "Toncoin", amount: 0, rate: 260 },
];

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function totalRub(tokens: Token[]) {
  return tokens.reduce((sum, t) => sum + t.amount * t.rate, 0);
}

export function formatRub(value: number) {
  return value.toLocaleString("ru-RU", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ₽";
}

export function useWallet() {
  const [tokens, setTokens] = useState<Token[]>(defaultTokens);

  useEffect(() => {
    setTokens(read<Token[]>(WALLET_KEY, defaultTokens));
  }, []);

  const update = useCallback((symbol: string, delta: number) => {
    setTokens((prev) => {
      const next = prev.map((t) =>
        t.symbol === symbol ? { ...t, amount: Math.max(0, Number((t.amount + delta).toFixed(4))) } : t,
      );
      try {
        window.localStorage.setItem(WALLET_KEY, JSON.stringify(next));
      } catch {
        /* ignore storage errors */
      }
      return next;
    });
  }, []);

  return { tokens, update };
}

export function usePremium() {
  const [premium, setPremium] = useState(false);

  useEffect(() => {
    setPremium(read<boolean>(PREMIUM_KEY, false));
  }, []);

  const toggle = useCallback((value: boolean) => {
    setPremium(value);
    try {
      window.localStorage.setItem(PREMIUM_KEY, JSON.stringify(value));
    } catch {
      /* ignore storage errors */
    }
  }, []);

  return { premium, toggle };
}
