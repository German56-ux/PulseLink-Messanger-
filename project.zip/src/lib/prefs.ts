import { useCallback, useEffect, useState } from "react";

export type Prefs = {
  notifySound: boolean;
  notifyBadge: boolean;
  notifyGroups: boolean;
  autoDownloadPhotos: boolean;
  autoDownloadVideos: boolean;
  saveToGallery: boolean;
  language: string;
  folders: string[];
};

const KEY = "pulslink.prefs";

export const defaultPrefs: Prefs = {
  notifySound: true,
  notifyBadge: true,
  notifyGroups: true,
  autoDownloadPhotos: true,
  autoDownloadVideos: false,
  saveToGallery: false,
  language: "ru",
  folders: ["Личное", "Работа"],
};

export function usePrefs() {
  const [prefs, setPrefs] = useState<Prefs>(defaultPrefs);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setPrefs({ ...defaultPrefs, ...(JSON.parse(raw) as Partial<Prefs>) });
    } catch {
      /* ignore */
    }
  }, []);

  const update = useCallback(<K extends keyof Prefs>(key: K, value: Prefs[K]) => {
    setPrefs((prev) => {
      const next = { ...prev, [key]: value };
      try {
        window.localStorage.setItem(KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  return { prefs, update };
}
