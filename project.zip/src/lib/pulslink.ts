import { supabase } from "@/integrations/supabase/client";

export type Profile = {
  id: string;
  username: string;
  display_name: string;
  bio: string;
  avatar_url: string | null;
  last_seen: string;
  is_banned: boolean;
  ban_reason: string | null;
  privacy_last_seen: string;
  privacy_avatar: string;
  privacy_messages: string;
  read_receipts: boolean;
  created_at: string;
  is_verified?: boolean;
  is_business?: boolean;
};

export type Chat = {
  id: string;
  type: string;
  title: string | null;
  avatar_url: string | null;
  created_by: string;
  created_at: string;
  last_message_at: string;
  username?: string | null;
  description?: string;
  is_verified?: boolean;
  is_business?: boolean;
  is_public?: boolean;
};


export type Message = {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string;
  attachment_url: string | null;
  attachment_type: string | null;
  reply_to: string | null;
  is_deleted: boolean;
  edited_at: string | null;
  created_at: string;
};

export type ChatListItem = {
  chat: Chat;
  members: Profile[];
  peer: Profile | null;
  lastMessage: Message | null;
  unread: number;
  lastReadAt: string;
  title: string;
  avatarUrl: string | null;
  verified: boolean;
  business: boolean;
};


const BUCKET = "pulslink";

export async function signedUrl(path: string | null): Promise<string | null> {
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const { data } = await supabase.storage.from(BUCKET).createSignedUrl(path, 3600);
  return data?.signedUrl ?? null;
}

export async function uploadFile(userId: string, file: File, folder: string) {
  const ext = file.name.split(".").pop() ?? "bin";
  const path = `${userId}/${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { upsert: false });
  if (error) throw error;
  return path;
}

export async function fetchMyProfile(userId: string) {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

export async function fetchChatList(userId: string): Promise<ChatListItem[]> {
  const { data: myMemberships, error } = await supabase
    .from("chat_members")
    .select("chat_id, last_read_at")
    .eq("user_id", userId);
  if (error) throw error;
  const chatIds = (myMemberships ?? []).map((m) => m.chat_id);
  if (chatIds.length === 0) return [];

  const [{ data: chats }, { data: allMembers }, { data: recentMessages }] = await Promise.all([
    supabase.from("chats").select("*").in("id", chatIds),
    supabase.from("chat_members").select("chat_id, user_id, role").in("chat_id", chatIds),
    supabase
      .from("messages")
      .select("*")
      .in("chat_id", chatIds)
      .order("created_at", { ascending: false })
      .limit(600),
  ]);

  const userIds = Array.from(new Set((allMembers ?? []).map((m) => m.user_id)));
  const { data: profiles } = await supabase.from("profiles").select("*").in("id", userIds);
  const profileMap = new Map<string, Profile>((profiles ?? []).map((p) => [p.id, p as Profile]));

  const items: ChatListItem[] = (chats ?? []).map((chatRow) => {
    const chat = chatRow as Chat;
    const lastReadAt =
      myMemberships?.find((m) => m.chat_id === chat.id)?.last_read_at ?? chat.created_at;
    const members = (allMembers ?? [])
      .filter((m) => m.chat_id === chat.id)
      .map((m) => profileMap.get(m.user_id))
      .filter(Boolean) as Profile[];
    const peer = chat.type === "direct" ? (members.find((m) => m.id !== userId) ?? null) : null;
    const chatMessages = ((recentMessages ?? []) as Message[]).filter((m) => m.chat_id === chat.id);
    const lastMessage = chatMessages[0] ?? null;
    const unread = chatMessages.filter(
      (m) => m.sender_id !== userId && new Date(m.created_at) > new Date(lastReadAt),
    ).length;
    return {
      chat,
      members,
      peer,
      lastMessage,
      unread,
      lastReadAt,
      title:
        chat.type === "direct"
          ? (peer?.display_name || peer?.username || "Чат")
          : (chat.title ?? (chat.type === "channel" ? "Канал" : "Группа")),
      avatarUrl: chat.type === "direct" ? (peer?.avatar_url ?? null) : chat.avatar_url,
      verified: chat.type === "direct" ? !!peer?.is_verified : !!chat.is_verified,
      business: chat.type === "direct" ? !!peer?.is_business : !!chat.is_business,
    };
  });


  return items.sort(
    (a, b) =>
      new Date(b.chat.last_message_at).getTime() - new Date(a.chat.last_message_at).getTime(),
  );
}

export async function fetchMessages(chatId: string) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("chat_id", chatId)
    .order("created_at", { ascending: true })
    .limit(500);
  if (error) throw error;
  return (data ?? []) as Message[];
}

export async function searchUsers(query: string, meId: string) {
  const q = query.trim();
  if (q.length < 2) return [];
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .or(`username.ilike.%${q}%,display_name.ilike.%${q}%`)
    .neq("id", meId)
    .limit(20);
  if (error) throw error;
  return (data ?? []) as Profile[];
}

export async function startDirectChat(meId: string, peerId: string) {
  const { data: mine } = await supabase.from("chat_members").select("chat_id").eq("user_id", meId);
  const { data: theirs } = await supabase
    .from("chat_members")
    .select("chat_id")
    .eq("user_id", peerId);
  const shared = (mine ?? [])
    .map((m) => m.chat_id)
    .filter((id) => (theirs ?? []).some((t) => t.chat_id === id));
  if (shared.length) {
    const { data: existing } = await supabase
      .from("chats")
      .select("*")
      .in("id", shared)
      .eq("type", "direct")
      .limit(1);
    if (existing && existing.length) return existing[0].id as string;
  }

  const { data: chat, error } = await supabase
    .from("chats")
    .insert({ type: "direct", created_by: meId })
    .select()
    .single();
  if (error) throw error;
  const { error: memberError } = await supabase
    .from("chat_members")
    .insert([
      { chat_id: chat.id, user_id: meId, role: "owner" },
      { chat_id: chat.id, user_id: peerId, role: "member" },
    ]);
  if (memberError) throw memberError;
  return chat.id as string;
}

export async function createGroupChat(meId: string, title: string, memberIds: string[]) {
  const { data: chat, error } = await supabase
    .from("chats")
    .insert({ type: "group", title, created_by: meId })
    .select()
    .single();
  if (error) throw error;
  const rows = [
    { chat_id: chat.id, user_id: meId, role: "owner" },
    ...memberIds.map((id) => ({ chat_id: chat.id, user_id: id, role: "member" })),
  ];
  const { error: memberError } = await supabase.from("chat_members").insert(rows);
  if (memberError) throw memberError;
  return chat.id as string;
}

export function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
}

export function formatDay(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const isToday = d.toDateString() === today.toDateString();
  if (isToday) return "Сегодня";
  return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "long" });
}

export function lastSeenLabel(profile: Profile | null) {
  if (!profile) return "";
  if (profile.privacy_last_seen === "nobody") return "был(а) недавно";
  const diff = Date.now() - new Date(profile.last_seen).getTime();
  if (diff < 60_000) return "в сети";
  if (diff < 3_600_000) return `был(а) ${Math.round(diff / 60_000)} мин назад`;
  return `был(а) ${formatDay(profile.last_seen)} в ${formatTime(profile.last_seen)}`;
}

export const USERNAME_RE = /^[a-zA-Z0-9_]{5,32}$/;

export async function isUsernameAvailable(username: string) {
  const value = username.trim();
  if (!USERNAME_RE.test(value)) return false;
  const { data, error } = await supabase.rpc("is_username_available", { _username: value });
  if (error) throw error;
  return !!data;
}

export async function createChannel(
  meId: string,
  input: { title: string; username: string; description: string; isPublic: boolean; memberIds: string[] },
) {
  const available = await isUsernameAvailable(input.username);
  if (!available) throw new Error("USERNAME_TAKEN");

  const { data: chat, error } = await supabase
    .from("chats")
    .insert({
      type: "channel",
      title: input.title.trim().slice(0, 60),
      username: input.username.trim(),
      description: input.description.trim().slice(0, 300),
      is_public: input.isPublic,
      created_by: meId,
    })
    .select()
    .single();
  if (error) throw error;

  const rows = [
    { chat_id: chat.id, user_id: meId, role: "owner" },
    ...input.memberIds.map((id) => ({ chat_id: chat.id, user_id: id, role: "member" })),
  ];
  const { error: memberError } = await supabase.from("chat_members").insert(rows);
  if (memberError) throw memberError;
  return chat.id as string;
}

export async function searchChannels(query: string) {
  const q = query.trim();
  let request = supabase.from("chats").select("*").eq("is_public", true).eq("type", "channel");
  if (q.length >= 2) request = request.or(`title.ilike.%${q}%,username.ilike.%${q}%`);
  const { data, error } = await request.order("last_message_at", { ascending: false }).limit(30);
  if (error) throw error;
  return (data ?? []) as Chat[];
}

export async function joinChannel(chatId: string, meId: string) {
  const { data: existing } = await supabase
    .from("chat_members")
    .select("id")
    .eq("chat_id", chatId)
    .eq("user_id", meId)
    .maybeSingle();
  if (existing) return;
  const { error } = await supabase
    .from("chat_members")
    .insert({ chat_id: chatId, user_id: meId, role: "member" });
  if (error) throw error;
}

export type ReportTargetType = "user" | "channel" | "group" | "bot" | "message";

export async function submitReport(input: {
  reporterId: string;
  targetType: ReportTargetType;
  targetId?: string | null;
  targetLabel: string;
  reason: string;
  details: string;
}) {
  const { error } = await supabase.from("reports").insert({
    reporter_id: input.reporterId,
    target_type: input.targetType,
    target_id: input.targetId ?? null,
    target_label: input.targetLabel.slice(0, 200),
    reason: input.reason,
    details: input.details.slice(0, 1000),
  });
  if (error) throw error;
}
