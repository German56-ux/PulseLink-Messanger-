import { Link } from "@tanstack/react-router";
import { MessageCircle, Users, Settings, User } from "lucide-react";

const items = [
  { to: "/chats", label: "Чаты", icon: MessageCircle },
  { to: "/contacts", label: "Контакты", icon: Users },
  { to: "/settings", label: "Настройки", icon: Settings },
  { to: "/profile", label: "Профиль", icon: User },
] as const;

export function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/90 backdrop-blur">
      <ul className="mx-auto grid max-w-2xl grid-cols-4">
        {items.map(({ to, label, icon: Icon }) => (
          <li key={to}>
            <Link
              to={to}
              className="flex flex-col items-center gap-1 py-2 text-[11px] text-muted-foreground"
              activeProps={{ className: "text-primary-glow" }}
            >
              <span className="grid h-8 w-16 place-items-center rounded-full transition-colors data-[status=active]:bg-primary/15">
                <Icon className="size-5" />
              </span>
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function SettingsRow({
  icon: Icon,
  tile,
  title,
  subtitle,
  right,
}: {
  icon: React.ComponentType<{ className?: string }>;
  tile: string;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <span className={`tile ${tile}`}>
        <Icon className="size-4" />
      </span>
      <div className="min-w-0 flex-1 text-left">
        <p className="truncate text-[15px]">{title}</p>
        {subtitle ? <p className="truncate text-xs text-muted-foreground">{subtitle}</p> : null}
      </div>
      {right}
    </div>
  );
}
