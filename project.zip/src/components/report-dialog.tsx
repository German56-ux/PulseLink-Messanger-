import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Flag } from "lucide-react";
import { useSession } from "@/hooks/use-session";
import { submitReport, type ReportTargetType } from "@/lib/pulslink";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const REASONS = [
  "Спам",
  "Мошенничество",
  "Оскорбления и травля",
  "Насилие",
  "Порнография",
  "Нарушение авторских прав",
  "Другое",
];

const TYPE_LABEL: Record<ReportTargetType, string> = {
  user: "аккаунт",
  channel: "канал",
  group: "группу",
  bot: "бота",
  message: "сообщение",
};

export function ReportDialog({
  targetType,
  targetId,
  targetLabel,
  trigger,
}: {
  targetType: ReportTargetType;
  targetId?: string | null;
  targetLabel: string;
  trigger?: ReactNode;
}) {
  const { user } = useSession();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState(REASONS[0]);
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);

  async function send() {
    if (!user?.id) return;
    setBusy(true);
    try {
      await submitReport({
        reporterId: user.id,
        targetType,
        targetId,
        targetLabel,
        reason,
        details: details.trim(),
      });
      toast.success("Жалоба отправлена команде PulsLink");
      setOpen(false);
      setDetails("");
    } catch {
      toast.error("Не удалось отправить жалобу");
    }
    setBusy(false);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="ghost" size="icon" aria-label="Пожаловаться">
            <Flag className="size-4" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Пожаловаться на {TYPE_LABEL[targetType]}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">{targetLabel}</p>
          <Select value={reason} onValueChange={setReason}>
            <SelectTrigger>
              <SelectValue placeholder="Причина" />
            </SelectTrigger>
            <SelectContent>
              {REASONS.map((r) => (
                <SelectItem key={r} value={r}>
                  {r}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="Опишите проблему (необязательно)"
            maxLength={1000}
          />
          <Button className="w-full" onClick={send} disabled={busy}>
            Отправить жалобу
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
