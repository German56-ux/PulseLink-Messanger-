import { BadgeCheck, Briefcase } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export function VerifiedBadge({
  verified,
  business,
  className = "",
}: {
  verified?: boolean;
  business?: boolean;
  className?: string;
}) {
  if (!verified && !business) return null;
  return (
    <TooltipProvider delayDuration={150}>
      <span className={`inline-flex shrink-0 items-center gap-1 ${className}`}>
        {verified ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <span aria-label="Подтверждён командой PulsLink">
                <BadgeCheck className="size-4 text-primary-glow" />
              </span>
            </TooltipTrigger>
            <TooltipContent>Подтверждён командой PulsLink</TooltipContent>
          </Tooltip>
        ) : null}
        {business ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <span aria-label="Бизнес-аккаунт">
                <Briefcase className="size-3.5 text-amber-400" />
              </span>
            </TooltipTrigger>
            <TooltipContent>Бизнес-аккаунт</TooltipContent>
          </Tooltip>
        ) : null}
      </span>
    </TooltipProvider>
  );
}
